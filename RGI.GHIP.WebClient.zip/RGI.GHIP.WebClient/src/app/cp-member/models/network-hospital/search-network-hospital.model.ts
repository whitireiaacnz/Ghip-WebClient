export class SearchNetworkHospital {
  uniqueId: number;
  hospitalId: number;
  hospitalName: string;
  contactPerson: string;
  address1: string;
  address2: string;
  city: string;
  cityId: number;
  district: string;
  state: string;
  country: string;
  mobileNo: string;
  phoneNo: string;
  emailID: string;
  pincode: string;
}
