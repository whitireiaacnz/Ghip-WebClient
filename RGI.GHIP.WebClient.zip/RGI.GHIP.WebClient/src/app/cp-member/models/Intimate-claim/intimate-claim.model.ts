import { IntimateClaimUploadDocuments } from './intimate-claim-upload-documents.model';

export class IntimateClaim {
  InsuredName: string;
  UHIDNumber: string;
  EmployeeID: string;
  MobileNumber: string;
  RelationShip: string;
  EmailID: string;
  PatientName: string;
  PatientUHID: string;
  PatientMobileNo: string;
  IntimatorMobileNo: string;
  PolicyName: string;
  PolicyNumber: string;
  PolicyStartDate: string;
  PolicyEndDate: string;
  IntimatorName: string;
  IntimationType: string;
  AdmissionDate = '';
  DischargeDate = '';
  DoctorName = '';
  Age: number;
  DiagnosisDetails = '';
  HospitalId: number;
  HospitalName = '';
  Address1: string;
  Address2: string;
  Address3: string;
  State: string;
  City: string;
  District: string;
  Pincode: number;
  Remarks: string;
  DocumentList: IntimateClaimUploadDocuments[] = [];
}
