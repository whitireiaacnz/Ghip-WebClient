export class CommCodePolicyno {
  policyNos: string[];
}
