export class RegistrationStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  registrationNo: string;
  registrationStatus: number;
}
