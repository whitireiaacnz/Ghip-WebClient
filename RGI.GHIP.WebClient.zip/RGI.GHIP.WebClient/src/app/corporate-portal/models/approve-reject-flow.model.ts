import { ApproveRejectRemark } from './approve-reject-remark.model';

export class ApproveRejectFlow {
  broker: ApproveRejectRemark = new ApproveRejectRemark();
  sm: ApproveRejectRemark = new ApproveRejectRemark();
  hr: ApproveRejectRemark = new ApproveRejectRemark();
}
