export class Guid {
  public static readonly Default: string = '00000000-0000-0000-0000-000000000000';
}
