export class PremiumTableDialogModal {
  constructor(
    public policy: any,
    public selfDependentDetailsList: any,
    public premiumAmountFormula: number,
    public premiumData: any
  ) {}
}
