import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SmComponent } from './components/sm/sm.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrokerRoutingModule } from '../broker/broker-routing.module';
import { CorporatePortalModule } from '../corporate-portal/corporate-portal.module';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { EditorModule } from '@tinymce/tinymce-angular';
import { MaterialModule } from '../material/material.module';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SMRoutingModule } from './sm-routing.module';
import { ProfileComponent } from './components/profile/profile.component';

@NgModule({
  declarations: [SmComponent, ProfileComponent],
  imports: [
    NgbModule,
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    SMRoutingModule,
    CorporatePortalModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    EditorModule,
    MaterialModule,
    SlickCarouselModule,
    BsDatepickerModule.forRoot(),
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class SmModule {}
