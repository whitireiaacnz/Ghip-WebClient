import { Component, OnInit } from '@angular/core';
import { SmMaster } from 'src/app/shared/models/CorporatePortal/sm-master.model';
import { AuthService } from 'src/app/shared/services/auth.service';
import { BrokerService } from 'src/app/broker/service/broker.service';
import { SMService } from '../../service/sm.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  sm: SmMaster;
  isProfileLoaded = false;

  constructor(private authService: AuthService, private smService: SMService) {}

  ngOnInit(): void {
    this.isProfileLoaded = false;
    this.smService.smProfile.subscribe(x => {
      this.sm = x;
      this.isProfileLoaded = true;
    });
  }
}
