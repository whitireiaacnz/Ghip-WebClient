export class PreEnrollmentMemberModel {
  id: number;
  employeeId: string;
  preEnrollmentPolicyId: number;
  insuredName: string;
  grade: string;
  dateOfBirth: Date;
  age: number;
  relationship: string;
  relationshipId: number;
  gender: string;
  mobileNo: string;
  emailId: string;
  sumInsured: string;
  dependentCount: number;
  isFinalSubmissionLocked: boolean;
  dependent: PreEnrollmentMemberModel[] = [];
}
