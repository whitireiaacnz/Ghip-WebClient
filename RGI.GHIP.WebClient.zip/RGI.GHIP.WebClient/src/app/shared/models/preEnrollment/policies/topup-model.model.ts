import { PeExtraBenefits } from './pe-extra-benefits.model';
import { TopupValues } from './topup-values.model';

export class TopupModel {
  peExtraBenefits: PeExtraBenefits = new PeExtraBenefits();
  peTopUp: TopupValues[] = [new TopupValues(null)];

  constructor(model) {
    Object.assign(this, model);
  }

  public isValid() {
    if (this.peExtraBenefits.sumInsuredType === 'EqualToSumInsured' || !this.peExtraBenefits.isAllowed) {
      this.peTopUp = [new TopupValues(null)];
      return true;
    }

    if (this.peExtraBenefits.sumInsuredType === 'Defined') {
      const insuredValues = this.peTopUp.map(el => {
        return el.stringValue;
      });
      const formattedValues = insuredValues.map(el => {
        return el.replace(/,/g, '');
      });
      const checkValues = this.checkIfDuplicateExists(formattedValues);

      if (checkValues) {
        this.peExtraBenefits.isValueRepeated = true;
        return false;
      } else {
        this.peExtraBenefits.isValueRepeated = false;
      }
    }
    if (this.peExtraBenefits.sumInsuredType === 'GradeWiseMultiples') {
      const insuredValues = this.peTopUp.map(el => {
        return el.grade.toLowerCase();
      });
      const formattedValues = insuredValues.map(el => {
        return el.replace(/,/g, '');
      });
      const checkValues = this.checkIfDuplicateExists(formattedValues);

      if (checkValues) {
        this.peExtraBenefits.isGradeWiseMultipleRepeated = true;
        return false;
      } else {
        this.peExtraBenefits.isGradeWiseMultipleRepeated = false;
      }
    }
    if (this.peExtraBenefits.sumInsuredType === 'GradeWiseDefined') {
      const insuredValues = this.peTopUp.map(el => {
        return el.grade.toLowerCase() + el.stringValue.toString();
      });
      const formattedValues = insuredValues.map(el => {
        return el.replace(/,/g, '');
      });
      const checkValues = this.checkIfDuplicateExists(formattedValues);

      if (checkValues) {
        this.peExtraBenefits.isGradeWiseDefinedRepeated = true;
        return false;
      } else {
        this.peExtraBenefits.isGradeWiseDefinedRepeated = false;
      }
    }
    let proceed = true;
    for (let index = 0; index < this.peTopUp.length; index++) {
      const element = new TopupValues(this.peTopUp[index]);
      this.peTopUp[index] = element;
      this.peTopUp[index].isValid(this.peExtraBenefits.sumInsuredType);
      proceed = proceed && element.isValid(this.peExtraBenefits.sumInsuredType);
    }
    return proceed;
  }

  checkIfDuplicateExists(sumInsured) {
    return new Set(sumInsured).size !== sumInsured.length;
  }
}
