export class MemberUploadFilesModel {
    constructor(public response: any) {}
}
