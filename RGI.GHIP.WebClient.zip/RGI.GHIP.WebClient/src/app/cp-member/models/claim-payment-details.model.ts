export class ClaimPaymentDetails {
  modeofPayment: string;
  payeename: string;
  bankName: string;
  accountNumber: string;
  transactionDate: string;
  transactionNumber: string;
  paidAmounts: string;
}
