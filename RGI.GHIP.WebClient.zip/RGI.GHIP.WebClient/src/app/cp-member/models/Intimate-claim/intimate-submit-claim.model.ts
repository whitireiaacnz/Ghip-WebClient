export class IntimateSubmitClaim {
  claimNumber: number;
}
