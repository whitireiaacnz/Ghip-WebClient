import { Policy } from 'src/app/cp-member/models/policy.model';

export class CorporatePolicyModel {
  id: number;
  name: string;
  code: string;
  logoImage: any;
  policies: Policy[] = [];
}
