import { SmMaster } from './sm-master.model';

export class ListSm {
  id: number;
  name: string;
  email: string;
  mobileNo: number;
  reportAllowed: boolean;
  endoresment: boolean;
  dashboard: boolean;
  key: string;
  reimbersementReport: boolean;
  cashlessReport: boolean;
  code: string;
  createdAt: string;
  dyanamicDashboard: boolean;
  lastLoggedInAt: string;
  loginEmailSentAt: string;
  loginSMSSentAt: string;
  smMaster: SmMaster;
  staticDashboard: boolean;
}
