import { Component, OnInit, Input, Injector, SimpleChanges, OnChanges } from '@angular/core';
import { BaseComponent } from 'src/app/shared/components/base.component';
import { CorporateModel } from 'src/app/shared/models/corporate/corporate.model';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { CreateSmComponent } from './create-sm/create-sm.component';
import { CorporatePortalService } from 'src/app/business-admin/services/corporate-portal.service';
import { ListSm } from 'src/app/shared/models/CorporatePortal/list-sm.model';
import { AlertService } from 'src/app/shared/services/alert.service';
import { ConfirmDialogModel } from 'src/app/shared/components/confirm-dialog/ConfirmDialogModel';
import { ConfirmDialogComponent } from 'src/app/shared/components/confirm-dialog/confirm-dialog.component';
import { ErrorMsgDialog } from 'src/app/shared/components/error-msg-dialog/ErrorMsgDialog';
import { ErrorMsgDialogComponent } from 'src/app/shared/components/error-msg-dialog/error-msg-dialog.component';

@Component({
  selector: 'app-list-sm',
  templateUrl: './list-sm.component.html',
  styleUrls: ['./list-sm.component.scss'],
})
export class ListSmComponent extends BaseComponent implements OnInit, OnChanges {
  @Input() corporate: CorporateModel;
  @Input() policyNumber: any;
  policy: any;
  searchText: string;
  isLoading: boolean;
  page = 1;
  pageSize = 5;
  smList: ListSm[] = [];
  smProperty = 'smProp';
  errorMsg: string[] = [];
  modalOption: NgbModalOptions = {};

  constructor(
    injector: Injector,
    private modalService: NgbModal,
    private readonly alertService: AlertService,
    private readonly corporatePortalService: CorporatePortalService
  ) {
    super(injector);
  }

  changePage() {
    this.page = 1;
  }

  open() {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    const modalRef = this.modalService.open(CreateSmComponent, this.modalOption);
    modalRef.componentInstance.corporate = this.corporate;
    modalRef.componentInstance.policy = this.policy;
    modalRef.componentInstance.smAddedSucessfully.subscribe(async isSmAdded => {
      if (isSmAdded === true) {
        this.isLoading = true;
        await this.getSm();
        this.isLoading = false;
      }
    });
  }

  async ngOnInit() {
    if (this.policyNumber !== 'Attach Policy') {
      this.isLoading = true;
      await this.getSm();
      this.isLoading = false;
    }
  }

  async ngOnChanges(changes: SimpleChanges) {
    this.corporatePortalService.updatedPolicies.subscribe((policyList: any[]) => {
      this.policy = policyList.find(policy => policy.policyNumber === this.policyNumber);
    });
    if (changes['policyNumber'] !== undefined && changes['corporate'] === undefined) {
      if (this.policyNumber !== 'Attach Policy') {
        this.isLoading = true;
        this.searchText = '';
        this.page = 1;
        this.smList = [];
        await this.getSm();
        this.isLoading = false;
      }
    }
  }

  async getSm() {
    this.isLoading = true;
    await this.corporatePortalService.getSmMappedPolicy(this.policy.id).then(result => {
      if (result) {
        this.smList = result;
      }
      this.isLoading = false;
    });
  }

  edit(sm) {
    this.modalOption.backdrop = 'static';
    this.modalOption.keyboard = false;
    const modalRef = this.modalService.open(CreateSmComponent, this.modalOption);
    modalRef.componentInstance.corporate = this.corporate;
    modalRef.componentInstance.policy = this.policy;
    modalRef.componentInstance.smAddedSucessfully.subscribe(isSmAdded => {
      if (isSmAdded === true) {
        this.isLoading = true;
        this.getSm();
        this.isLoading = false;
      }
    });
    modalRef.componentInstance.smDetails = sm;
  }

  async removeSM(smId) {
    let result;
    const message = `Are you sure you want to delete?`;

    const dialogData = new ConfirmDialogModel('Confirm Action', message);

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: dialogData,
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(async dialogResult => {
      result = dialogResult;
      if (result) {
        try {
          this.isLoading = true;
          await this.corporatePortalService
            .deleteSM(smId)
            .then(x => {
              this.isLoading = true;
              this.getSm();
              this.isLoading = false;
              this.alertService.success('SM deleted successfully');
            })
            .catch(errorData => {
              const errorList = errorData.error.errors;
              this.openErrorModal(errorList);
            });
          this.isLoading = false;
        } catch (error) {
          this.alertService.error('Error occured');
          this.isLoading = false;
        }
      }
    });
  }

  openErrorModal(errorList) {
    this.errorMsg = [];
    errorList.forEach(errorDescription => {
      this.errorMsg.push(errorDescription.message);
    });

    const dialogData = new ErrorMsgDialog(this.errorMsg);

    this.dialog.open(ErrorMsgDialogComponent, {
      data: dialogData,
      disableClose: true,
    });
  }
}
