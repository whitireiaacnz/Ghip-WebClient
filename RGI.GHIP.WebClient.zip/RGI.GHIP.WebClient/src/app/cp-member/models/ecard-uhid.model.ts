export class EcardUhid {
    policyNo: string;
    uHID: string[];
}
