export class CoverageValueField {
  valueField: string;
}
