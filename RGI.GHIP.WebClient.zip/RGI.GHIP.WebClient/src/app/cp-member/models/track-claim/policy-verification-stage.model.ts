export class PolicyVerificationStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  policyverificationStatus: number;
}
