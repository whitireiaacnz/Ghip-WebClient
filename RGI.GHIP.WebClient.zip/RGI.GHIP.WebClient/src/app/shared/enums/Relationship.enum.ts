export enum Relationship {
    MOTHERINLAW = 'Mother-In-Law',
    FATHERINLAW = 'Father-In-Law',
    MOTHER = 'Mother',
    FATHER = 'Father'
}
