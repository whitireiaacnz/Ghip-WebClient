import * as moment from 'moment';

export class PreEnrollmentPeriodModel {
  id: number;
  policyId: number;
  startDate: any;
  endDate: any;
  status: any;
}
