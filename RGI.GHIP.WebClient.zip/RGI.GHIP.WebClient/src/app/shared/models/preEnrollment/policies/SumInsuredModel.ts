export class SumInsuredModel {
  value: string;
  isInvalid = false;
  constructor(value = '') {
    this.value = value;
    // this.checkValidity();
  }

  public checkValidity() {
    const sumInsuredIntValue = Number(this.value.toString().replace(/,/g, ''));
    const isFloat = Number(sumInsuredIntValue) === sumInsuredIntValue && sumInsuredIntValue % 1 !== 0;
    if (isFloat) {
      this.isInvalid = true;
    } else {
      this.isInvalid =
        !sumInsuredIntValue || isNaN(sumInsuredIntValue) || Number(sumInsuredIntValue.toString().trim()) <= 0;
    }
    return !this.isInvalid;
  }
}
