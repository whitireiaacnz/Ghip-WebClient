export class TokenModel {
  accessToken: string;
  username: string;
  expiresOn: Date;
}
