export class ApproveReject {
  remark: string;
  isApproved: boolean;
  isRejected: boolean;
}
