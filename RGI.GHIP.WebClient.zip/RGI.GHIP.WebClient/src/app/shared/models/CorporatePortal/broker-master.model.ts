export class BrokerMaster {
  code: string = null;
  email: string = null;
  id: string = null;
  loginEmailSentAt: string = null;
  loginSMSSentAt: string = null;
  mobileNo: string = null;
  name: string = null;
}
