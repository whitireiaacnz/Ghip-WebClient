export class ListBroker {
  id: number;
  name: string;
  email: string;
  mobileNo: number;
  reportAllowed: boolean;
  endoresment: boolean;
  dashboard: boolean;
  key: string;
  reimbersementReport: boolean;
  cashlessReport: boolean;
  code: string;
  createdAt: string;
  dyanamicDashboard: boolean;
  lastLoggedInAt: string;
  loginEmailSentAt: string;
  loginSMSSentAt: string;
  staticDashboard: boolean;
}
