export class CorporateSummaryModel {
  id: number;
  name: string;
  code: string;
  logoUrl: string;
  logoImage: string;
}
