export class PreEnrollmentPolicyRelationshipModel {
  id: number;
  label: string;
  type: string;
  count: number;
  minAgeLimit: number;
  maxAgeLimit: number;
  isConfigurable: boolean;
  isEnabled: boolean;
}
