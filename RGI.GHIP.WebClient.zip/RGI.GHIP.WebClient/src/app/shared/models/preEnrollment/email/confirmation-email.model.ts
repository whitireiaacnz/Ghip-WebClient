export class ConfirmationEmail {
    sendRegistrationConfirmationEmail: boolean;
    registrationConfirmationEmailTemplate: string;
    registrationConfirmationEmailBccs: string;
    registrationConfirmationEmailCcs: string;
    registrationConfirmationEmailSubject: string;
    registrationConfirmationEmailFile: any;
    confirmationEmailFileName: string;
}
