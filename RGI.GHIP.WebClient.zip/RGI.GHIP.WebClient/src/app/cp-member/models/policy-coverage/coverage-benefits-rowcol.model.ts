import { CoverageValueField } from './coverage-value-field.model';

export class CoverageBenefitsRowCol {
  headerTextField: string;
  columnField: CoverageValueField[] = [];
  rowField: CoverageValueField[] = [];
}
