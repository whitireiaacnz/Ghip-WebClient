export class PolicyCommunicationCodes {
  policyId: string;
  communicationCode: string;
}
