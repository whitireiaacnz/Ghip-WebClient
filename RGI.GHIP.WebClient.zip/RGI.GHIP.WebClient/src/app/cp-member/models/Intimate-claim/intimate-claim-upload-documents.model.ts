export class IntimateClaimUploadDocuments {
  FileName: string;
  FileBytes: any;
  DocTypeId: any;
  OriginalFile: any;
}
