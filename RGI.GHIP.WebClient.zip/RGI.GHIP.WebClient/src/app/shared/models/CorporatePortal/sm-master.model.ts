export class SmMaster {
  code: string = null;
  email: string = null;
  id: string = null;
  loginEmailSentAt = null;
  loginSMSSentAt = null;
  mobileNo: string = null;
  name: string = null;
}
