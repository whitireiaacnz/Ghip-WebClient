import { BrokerMaster } from './broker-master.model';
import { Privileges } from 'src/app/corporate-portal/models/privileges.model';

export class Broker extends Privileges {
  brokerMaster: BrokerMaster = new BrokerMaster();
}
