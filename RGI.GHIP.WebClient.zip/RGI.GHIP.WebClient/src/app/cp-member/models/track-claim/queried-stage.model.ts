export class QueriedStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  queriedDate: string;
  queriedDetails: number;
}
