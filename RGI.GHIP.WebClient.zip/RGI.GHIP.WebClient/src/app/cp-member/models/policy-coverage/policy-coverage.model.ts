import { HealthCoverage } from './health-coverage.model';

export class PolicyCoverage {
  coverageHealth: HealthCoverage[] = [];
}
