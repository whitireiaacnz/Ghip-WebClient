export class ListHr {
  id: number;
  memberId: number;
  name: string;
  email: string;
  mobileNo: number;
  hrEmpId: string;
  reportAllowed: boolean;
  endoresment: boolean;
  dashboard: boolean;
  member: null;
  key: string;
  lastLoggedInAt: string;
  loginEmailSentAt: string;
  loginSMSSentAt: string;
  createdAt: string;
}
