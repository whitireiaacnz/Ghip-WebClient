import { MemberModel } from './member.model';
import { PreEnrollmentAdditionSumOptionModel } from 'src/app/shared/models/preEnrollment/policies/PreEnrollmentAdditionSumOptionModel';

export class PreEnrollmentMemberPolicyModel {
  members: MemberModel[] = [];
  psiModel: PreEnrollmentAdditionSumOptionModel;
  esiModel: PreEnrollmentAdditionSumOptionModel;
  topupModel: PreEnrollmentAdditionSumOptionModel;
}
