import { FieldConfig } from 'src/app/dyanamic-fields-form/model/form-fields';

export class MemberModel {
  id: number;
  insuredName: string;
  employeeId: string;
  preEnrollmentPolicyId: number;
  relationshipId: number;
  fieldsJson: string;
  psi: number;
  esi: number;
  topup: number;
  fields: FieldConfig[];
  isFinalSubmissionLocked: boolean;
  isSelfProfileEdited: boolean;
  disableDependentDeletion = false;
  preEnrollmentPolicy: any;
  psiPremiumModel: any[];
  esiPremiumModel: any[];
  topupPremiumModel: any[];
  siPremiumModel: any[];
  dateOfJoining: Date;
}
