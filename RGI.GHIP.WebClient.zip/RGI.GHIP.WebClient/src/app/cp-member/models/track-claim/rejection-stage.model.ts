export class RejectionStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  rejectedStatus: string;
}
