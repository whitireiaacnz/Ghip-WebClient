export class CredentialsFormat {
  'id': number;
  'policyNumber': number;
  'UserNameType': string;
  'PasswordType': string;
  'key': string;
}
