export class ErrorMsgDialog {
  constructor(public errorList: string[]) {}
}
