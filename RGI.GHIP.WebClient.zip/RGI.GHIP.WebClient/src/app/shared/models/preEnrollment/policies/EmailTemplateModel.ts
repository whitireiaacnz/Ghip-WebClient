export class EmailTemplateModel {
  id: number;
  welcomeEmailTemplate: string;
  confirmationEmailTemplate: string;
  reminderEmailTemplate: string;
}
