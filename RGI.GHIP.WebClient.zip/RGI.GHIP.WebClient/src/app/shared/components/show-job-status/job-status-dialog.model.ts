export class JobStatusDialog {
    constructor(public jobStatus: string, public url: string, public policyId: any, public statusId: any) {}
}

