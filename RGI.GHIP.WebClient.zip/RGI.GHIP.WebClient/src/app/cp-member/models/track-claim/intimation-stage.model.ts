export class IntimationStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  intimationNumber: string;
  intimationSource: number;
}
