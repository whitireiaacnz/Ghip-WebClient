export class FamilyClaimsCount {
  policyNo: string;
  employeeId: string;
  insuredName: string;
  relationship: string;
  uhid: string;
  age: number;
  claimCount: number;
  isSelfCovered: boolean;
}
