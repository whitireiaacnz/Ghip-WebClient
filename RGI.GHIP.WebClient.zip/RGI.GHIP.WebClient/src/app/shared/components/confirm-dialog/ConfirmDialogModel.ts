export class ConfirmDialogModel {
  constructor(public title: string, public message: string, public no = 'No', public yes = 'Yes') {}
}
