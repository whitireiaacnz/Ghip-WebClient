import { SmMaster } from './sm-master.model';
import { Privileges } from 'src/app/corporate-portal/models/privileges.model';

export class Sm extends Privileges {
  smMaster: SmMaster = new SmMaster();
  policyId: string;
}
