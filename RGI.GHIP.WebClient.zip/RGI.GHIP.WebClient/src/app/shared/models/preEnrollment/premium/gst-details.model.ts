export class GstDetails {
  isGSTExempted: boolean;
  gSTFileUpload: string;
  gSTPercentage: number;
}
