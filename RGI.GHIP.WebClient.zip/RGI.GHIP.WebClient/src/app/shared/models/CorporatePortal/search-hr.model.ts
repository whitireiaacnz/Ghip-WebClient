export class SearchHr {
  name: string;
  policyNo: number;
  isActive: boolean;
  commCodes: string[] = [];
}
