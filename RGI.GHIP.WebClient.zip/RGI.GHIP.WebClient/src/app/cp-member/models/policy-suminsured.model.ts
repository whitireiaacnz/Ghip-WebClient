export class PolicyAllowedSumInsured {
  GradeId: number;
  GradeDescription: string;
  sumInsured: number;
}
