export class DisallowedAmount {
    billDescription: string;
    subBillTypeDescription: boolean;
    claimedAmount: boolean;
    disallowedAmount: string;
    moreInformation: number;
  }
