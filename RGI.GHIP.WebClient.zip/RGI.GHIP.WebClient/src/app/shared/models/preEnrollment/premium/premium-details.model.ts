export class PremiumDetails {
  isPremiumVisible: boolean;
  isPremiumApplicable: boolean;
  premiumType: string;
  isRefundApplicable: boolean;
}
