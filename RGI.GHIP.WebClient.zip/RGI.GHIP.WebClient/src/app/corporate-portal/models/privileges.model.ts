export class Privileges {
  public reportAllowed = false;
  public endoresment = false;
  public dashboard = false;
  public reimbersementReport = false;
  public cashlessReport = false;
  public dyanamicDashboard = false;
  public staticDashboard = false;
}
