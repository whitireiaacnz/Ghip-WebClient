import { CoverageBenefitsRowCol } from './coverage-benefits-rowcol.model';

export class CoverageSubtype {
  displayTextField: string;
  displayDescrptionField: string;
  subetypelistField: CoverageBenefitsRowCol[] = [];
}
