export class PolicyInfoModel {
  activeInsured: string;
  totalEndorsements: string;
  cashlessClaims: string;
  reimbursementClaims: string;
}
