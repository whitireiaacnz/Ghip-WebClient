export class SettlementStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
}
