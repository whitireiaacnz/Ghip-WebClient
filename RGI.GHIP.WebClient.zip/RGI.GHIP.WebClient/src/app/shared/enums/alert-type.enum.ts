export class AlertTypeEnum {
  public static readonly Error: string = 'Danger';
  public static readonly Warning: string = 'Warning';
  public static readonly Info: string = 'Info';
  public static readonly Success: string = 'Success';
}
