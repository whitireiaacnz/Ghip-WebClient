import { Validators } from '@angular/forms';

export interface Validator {
  name: string;
  validator: any;
  message: string;
  regex?: string;
}
export interface FieldConfig {
  label?: string;
  name?: string;
  inputType?: string;
  options?: string[];
  collections?: any;
  type: string;
  value?: any;
  validations?: Validator[];
  validationsCustom?: string[];
  instructions?: string;
  section?: string;
  isMandatory?: boolean;
  isEditable?: boolean;
  isVisible?: boolean;
  order?: number;
}
