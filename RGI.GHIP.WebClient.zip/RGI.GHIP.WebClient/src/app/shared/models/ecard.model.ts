export class Ecard {
  file: any;
}
