export class MedicalScrutinyStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  medicalScrutinyStatus: number;
}
