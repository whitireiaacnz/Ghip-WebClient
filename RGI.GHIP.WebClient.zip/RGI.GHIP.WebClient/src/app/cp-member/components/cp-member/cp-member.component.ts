import { Component, OnInit, OnDestroy, Injector } from '@angular/core';
import { PreEnrollmentMemberService } from 'src/app/member/services/preEnrollment-member.service';
import { AuthService } from 'src/app/shared/services/auth.service';
import { Subscription } from 'rxjs';
import { BaseComponent } from 'src/app/shared/components/base.component';
import { CPMemberService } from '../../services/CPMember.service';
import { Policy } from '../../models/policy.model';
import { CPPolicyService } from 'src/app/corporate-portal/services/cp-policy.service';

@Component({
  selector: 'app-cp-member',
  templateUrl: './cp-member.component.html',
  styleUrls: ['./cp-member.component.scss'],
})
export class CpMemberComponent extends BaseComponent implements OnInit, OnDestroy {
  isAuthenticated: boolean;
  subscription: Subscription;
  role: any;
  policyList: Policy[] = [];
  currentPolicy: Policy;
  policyNumber: string;
  isHr: boolean;
  isMember: boolean;
  isHrView = false;

  constructor(
    injector: Injector,
    private readonly authService: AuthService,
    private policyService: CPPolicyService,
    private cpMemberService: CPMemberService
  ) {
    super(injector);
  }

  async ngOnInit() {
    super.ngOnInit();
    // check for CPMember role
    this.memberFunc();
    this.role = this.authService.role;

    await this.cpMemberService.IsMemberOrHr();

    await this.policyService.getMemberHrPolicies().then(p => {
      const unsortedPolicies = p[0].policies;
      const sortedPolicies = this.sortPolicies(unsortedPolicies);
      this.policyService.allPolicies.next(sortedPolicies);
      this.policyService.policies.next(sortedPolicies);
      this.policyService.currentPolicy.next(sortedPolicies[0]);
    });

    this.cpMemberService.isHrView.subscribe(v => {
      this.isHrView = v;
    });

    this.policyService.currentPolicy.subscribe(async (policy: any) => {
      this.currentPolicy = policy;
      this.policyNumber = this.currentPolicy.policyNumber;

      this.isHr = this.cpMemberService.isHr;
      this.isMember = this.cpMemberService.isMember;
      if (this.policyNumber !== undefined && this.isHr === true && this.isHrView) {
        this.hrFunc();
      }
      if (this.policyNumber !== undefined && this.isMember === true && this.currentPolicy.isMemberEnrolled) {
        this.memberFunc();
      }
    });
  }

  sortPolicies(policies) {
    policies.sort(function compare(a, b) {
      const dateA = new Date(a.riskStartDate);
      const dateB = new Date(b.riskStartDate);
      return <any>dateB - <any>dateA;
    });
    policies.sort(policy => {
      return policy.isActive === false ? 0 : policy ? -1 : 1;
    });
    const activePolicyArray = [];
    const inactivePolicyArray = [];
    policies.forEach(policy => {
      if (policy.isActive) {
        activePolicyArray.push(policy);
      } else {
        inactivePolicyArray.push(policy);
      }
    });
    activePolicyArray.reverse();
    policies = [];
    policies = [...activePolicyArray, ...inactivePolicyArray];

    return policies;
  }

  async hrFunc() {
    await this.cpMemberService
      .getHRProfile()
      .then(x => {
        this.cpMemberService.hrDetails.next(x);
      })
      .catch(x => {
        console.log('error');
      });

    await this.cpMemberService
      .UpdateHrSeenNotification()
      .then(x => {
        console.log(x);
      })
      .catch(x => {
        console.log('error');
      });

    await this.cpMemberService
      .GetUnSeenHrNotificationCount()
      .then(x => {
        console.log(x);
      })
      .catch(x => {
        console.log('error');
      });
  }

  async memberFunc() {
    await this.cpMemberService
      .getMemberFamily(this.currentPolicy.policyNumber)
      .then(x => {
        console.log(x);
      })
      .catch(x => {
        console.log('error');
      });

    await this.cpMemberService
      .UpdateMemberSeenNotification(this.currentPolicy.policyId)
      .then(x => {
        console.log(x);
      })
      .catch(x => {
        console.log('error');
      });

    await this.cpMemberService
      .GetUnSeenMemberNotificationCount()
      .then(x => {
        console.log(x);
      })
      .catch(x => {
        console.log('error');
      });
  }

  toggleSidebar(event) {
    event.currentTarget.offsetParent.classList.toggle('close-sidebar');
    event.currentTarget.classList.toggle('closed');
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }
}
