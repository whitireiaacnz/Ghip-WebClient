import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Policy } from 'src/app/cp-member/models/policy.model';
import { CPMemberService } from 'src/app/cp-member/services/CPMember.service';
import * as FileSaver from 'file-saver';
import { CPPolicyService } from 'src/app/corporate-portal/services/cp-policy.service';
import { AlertService } from 'src/app/shared/services/alert.service';
import { EndorsementService } from 'src/app/corporate-portal/services/endorsement.service';

@Component({
  selector: 'app-member-endorsement',
  templateUrl: './member-endorsement.component.html',
  styleUrls: ['./member-endorsement.component.scss'],
})
export class MemberEndorsementComponent implements OnInit, OnChanges {
  @Input() policy: Policy;
  @Input() loadDetails;
  memberDetails: any[] = [];
  isDetailsLoaded = false;

  error = [];

  file: any;
  isFileUploaded = true;

  isMemberEndorsementSampleLoaded = true;

  constructor(
    private policyService: CPPolicyService,
    private alertservise: AlertService,
    private endorsementService: EndorsementService,
    private cpMemberService: CPMemberService
  ) {}
  slideConfig = {
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  ngOnChanges(changes: SimpleChanges) {
    if (changes['policy'] !== undefined) {
      this.file = null;
      this.error = [];
      this.getMember();
    }
  }

  async ngOnInit() {
    this.loadDetails.subscribe(isLoadDetails => {
      if (isLoadDetails === 'member') {
        this.getMember();
      }
    });
  }

  getMember() {
    this.memberDetails = [];
    this.isDetailsLoaded = false;
    this.endorsementService
      .getMemberEndorsed(this.policy.policyId)
      .then(memberDetail => {
        this.memberDetails = memberDetail;
        this.isDetailsLoaded = true;
      })
      .catch(x => {
        console.log(x);
      });
  }

  async getSampleMemberExcelFile() {
    this.isMemberEndorsementSampleLoaded = false;
    await this.endorsementService.getMemberEndorsementSample().then(
      result => {
        this.isMemberEndorsementSampleLoaded = true;
        FileSaver.saveAs(result, `MemberEndorsementSample.xlsx`);
      },
      error => {}
    );
  }

  uploadFile(event) {
    if (event.target.files.length > 0) {
      this.error = [];
      this.file = event.target.files[0];
    }
  }

  deleteFile() {
    this.file = null;
    this.error = [];
  }

  async submitFile() {
    this.isFileUploaded = false;
    this.error = [];
    const formData = new FormData();
    formData.append('file', this.file);
    await this.endorsementService
      .excelMemberEndorsement(this.policy.policyId, formData)
      .then(x => {
        this.getMember();
        this.isFileUploaded = true;
        this.file = null;
        this.alertservise.success('Added endorsement.');
      })
      .catch(error => {
        this.isFileUploaded = true;
        this.error = error.error;
        this.alertservise.success('Error Occured.');
      });
  }
}
