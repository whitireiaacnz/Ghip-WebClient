export class DocumentationStage {
  headerText: string;
  isCurrentState: boolean;
  isStageCompleted: boolean;
  completionDate: string;
  inwardNumber: string;
  documentStatus: number;
}
