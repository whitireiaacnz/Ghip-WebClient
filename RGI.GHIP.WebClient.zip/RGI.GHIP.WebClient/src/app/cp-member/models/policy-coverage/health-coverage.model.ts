import { CoverageSubtype } from './coverage-subtype.model';

export class HealthCoverage {
  displayTextField: string;
  displayDescrptionField: string;
  coverageListField: CoverageSubtype[] = [];
}
