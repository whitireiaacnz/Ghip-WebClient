export class ApproveRejectRemark {
  remark: string;
  isApproved: boolean;
  isRejected: boolean;
  at: string;
  by: string;
}
