export class PreEnrollmentPolicyMemberFieldModel {
  id: number;
  label: string;
  isConfigurable: boolean;
  isEnabled: boolean;
  isMandatoryForSelf: boolean;
  isVisibleForSelf: boolean;
  isMandatoryForDependent: boolean;
  isVisibleForDependent: boolean;
  isEditableForDependent: boolean;
  isEditableForSelf: boolean;
}
