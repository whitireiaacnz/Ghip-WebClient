export class ClaimCommunicationDetails {
  recipientName: string;
  events: string;
  smsSent: string;
  emailSent: string;
}
