export class NoteMsgDialogModel {
  constructor(public title: string, public message: string, public text = 'Ok') {}
}
