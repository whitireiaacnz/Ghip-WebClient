export class WelcomeEmailTimeModel {
    constructor(public dateTimeAllocation: any) {}
}
