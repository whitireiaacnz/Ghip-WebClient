# rgi-ghip-web</br>
### Storage Account AccessKeys
**Develop Environment:** https://stghipdevweb.z29.web.core.windows.net/</br>
**Production Environment:** https://stghipprodweb.z29.web.core.windows.net/</br>