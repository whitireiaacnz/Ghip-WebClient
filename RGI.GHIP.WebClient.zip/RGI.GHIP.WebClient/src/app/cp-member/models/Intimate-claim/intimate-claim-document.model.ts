export class IntimateClaimDocument {
  description: string;
  active: boolean;
  documentId: number;
  documentType: string;
  isMandatory: boolean;
}
