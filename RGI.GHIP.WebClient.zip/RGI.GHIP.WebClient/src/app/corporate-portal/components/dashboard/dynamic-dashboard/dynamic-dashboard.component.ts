import { Component, OnInit, Input } from '@angular/core';
import { Policy } from 'src/app/cp-member/models/policy.model';

@Component({
  selector: 'app-dynamic-dashboard',
  templateUrl: './dynamic-dashboard.component.html',
  styleUrls: ['./dynamic-dashboard.component.scss'],
})
export class DynamicDashboardComponent implements OnInit {
  @Input() policy: Policy;

  constructor() {}

  ngOnInit(): void {}
}
